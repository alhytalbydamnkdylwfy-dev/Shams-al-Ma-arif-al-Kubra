(() => {
  const frame = document.getElementById('pdfViewer');
  const empty = document.getElementById('emptyState');
  const download = document.getElementById('downloadLink');

  // The PDF is supplied by the site owner as ./book.pdf.
  fetch('book.pdf', { method: 'HEAD' })
    .then(response => {
      if (response.ok) {
        frame.hidden = false;
        empty.hidden = true;
        download.hidden = false;
      } else {
        download.hidden = true;
      }
    })
    .catch(() => { download.hidden = true; });
})();
